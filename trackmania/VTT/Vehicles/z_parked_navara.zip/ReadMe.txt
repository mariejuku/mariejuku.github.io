Original Author: Bizarre Creations

Original model from Blur, updated by PortalCat using Blender and Substance Painter.
Engine sounds ripped from Forza Horizon 4, edited in Audition.