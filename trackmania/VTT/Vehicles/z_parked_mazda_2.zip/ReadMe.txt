Original author: Turn 10 Studios
Mazda 2 (Demio) from FM4, engine sounds from AC.