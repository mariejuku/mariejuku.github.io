Lamborgini Aventador LP700-4
___________________________________________________________________________________________________________________________________________________________________

Original Author: Turn 10 Studios (Forza 4), with a few parts from a Maserati GranTurismo S in NFS Shift 2 ^^
Rip model, UVs, a huge part of the texture workflow & TMUF export: GKRacer

TM� convert: krapS

700 HP of pure gorgeousness, live from Sant'Agata Bolognese, just for you!